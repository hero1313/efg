
<?php $__env->startSection('content'); ?>
<button class='btn btn-primary add-project' data-toggle="modal" data-target="#add-porject">პროექტის დამატება</button>
<div class="container-fluid flex-grow-1 container-p-y">

    <div class="card mt-5">
        <h5 class="card-header">პროექტები</h5>
        <div class="table-responsive text-nowrap">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>დასახელება</th>
                        <th>რეზერვის პროცენტი</th>
                        <th>სარეზერვო თანხა</th>
                        <th>დაუკავებელი რეზერვი</th>
                        <th>დაკავებული რეზერვი</th>
                        <th>დაუკავებელი ავანსი</th>
                        <th>ავანსის პროცენტი</th>
                        <th>დაკავებული ავანსი</th>
                        <th>გადახდილი ავანსი</th>
                        <th>სერთიფიკატიდან გადახდილი თანხა</th>
                        <th>ჯამურად გადახდილი თანხა</th>
                        <th>დარჩენილი გადასახადი</th>
                        <th>ღირებულება</th>
                        <th>დაწყება</th>
                        <th>დასრულება</th>
                        <th>გარანტიის კოდი</th>
                        <th>სტატუსი</th>
                        <th>დეტალები</th>
                        <th>წაშლა</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $planePay = DB::table('project_plans')
                        ->where('project_id', '=', $project->id)
                        ->where('status', '=', null)
                        ->sum('pay');
                    ?>
                    <tr>
                        <td><?php echo e($project->name); ?></td>
                        <td><?php echo e($project->reserve_percent); ?>%</td>
                        <td><?php echo e($project->start_reserve); ?> ₾</td>
                        <td><?php echo e($project->start_reserve - $project->reserve); ?> ₾</td>
                        <td><?php echo e($project->reserve); ?> ₾</td>
                        <td><?php echo e($project->avance); ?>₾</td>
                        <td><?php echo e($project->avance_percent); ?>%</td>
                        <td><?php echo e($project->start_avance - $project->avance); ?>₾</td>
                        <td><?php echo e($project->start_avance); ?>₾</td>
                        <td><?php echo e($planePay); ?>₾</td>
                        <td><?php echo e($planePay + $project->start_avance); ?>₾</td>
                        <td><?php echo e($project->price - ($planePay + $project->start_avance)); ?>₾</td>
                        <td><?php echo e($project->price); ?> ₾</td>
                        <td><?php echo e($project->start_date); ?></td>
                        <td><?php echo e($project->end_date); ?></td>
                        <td><?php echo e($project->guarantee_id); ?></td>
                        <td>
                            <?php if($project->status == 1): ?>
                            <button class='btn btn-success'>აქტიური</button>
                            <?php elseif($project->status == 0): ?>
                            <button class='btn btn-danger'>დასრულებული</button>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('show.project',$project->id)); ?>">
                                <button class='btn btn-primary'>დეტალები</button>
                            </a>
                        </td>
                        <td>
                            <button class='btn btn-primary' data-toggle="modal"
                                data-target="#edit_project_<?php echo e($project->id); ?>">რედაქტირება</button>
                        </td>
                        <td>
                            <form action="<?php echo e(route('delete.project', $project->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">წაშლა</button>
                            </form>
                        </td>
                    </tr>

                    <div class="modal fade bd-example-modal-lg" id="edit_project_<?php echo e($project->id); ?>" tabindex="-1"
                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">გეგმის დამატება</h5>
                                    <button type="button" class="close btn btn-primary" data-dismiss="modal"
                                        aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action='<?php echo e(route("update.project",$project->id)); ?>' method='post'>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class='row'>
                                            <div class="form-group col-12 col-md-6 mt-3">
                                                <label for="exampleInputEmail1">დასახელება</label>
                                                <input type="text" required value="<?php echo e($project->name); ?>" name='name'
                                                    required class="form-control mt-2">
                                            </div>
                                            <div class="form-group col-12 col-md-6 mt-3">
                                                <label for="exampleInputEmail1">ფოტო</label>
                                                <input type="file" value="<?php echo e($project->image); ?>" name='image'
                                                    class="form-control mt-2">
                                            </div>
                                            <div class="form-group col-12 col-md-6 mt-3">
                                                <label for="exampleInputEmail1">დაწყების თარიღი</label>
                                                <input type="date" required value="<?php echo e($project->start_date); ?>"
                                                    name='start_date' required class="form-control mt-2">
                                            </div>
                                            <div class="form-group col-12 col-md-6 mt-3">
                                                <label for="exampleInputEmail1">დასრულების თარიღი</label>
                                                <input type="date" required value="<?php echo e($project->end_date); ?>"
                                                    name='end_date' class="form-control mt-2">
                                            </div>
                                            <div class="form-group col-12 col-md-6 mt-3">
                                                <label for="exampleInputEmail1">გარანტიები</label>
                                                <select class="form-select mt-2" name='guarantee_id'
                                                    aria-label="Default select example">
                                                    <option value="<?php echo e($project->guarantee_id); ?>">
                                                        <?php echo e($project->guarantee_id); ?></option>

                                                    
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-12 col-md-6 mt-3">
                                                <label for="exampleInputEmail1">ჯამური ღირებულება</label>
                                                <input type="number" required name='price' step="0.01" value="<?php echo e($project->price); ?>"
                                                    class="form-control mt-2">
                                            </div>
                                            <!-- <div class="form-group col-12 col-md-6 mt-3">
                                                <label for="exampleInputEmail1">ავანსის პროცენტი</label>
                                                <input type="number" min='0' max='100' name='avance_percent'
                                                    value="<?php echo e($project->avance_percent); ?>" required
                                                    class="form-control mt-2">
                                            </div> -->
                                            <div class="form-group col-12 col-md-6 mt-3">
                                                <label for="exampleInputEmail1">რეზერვის პროცენტი</label>
                                                <input type="number" min='0' max='100' name='reserve_percent'
                                                    value="<?php echo e($project->reserve_percent); ?>" required
                                                    class="form-control mt-2">
                                            </div>
                                            <div class="form-group col-12 col-md-6 mt-2">
                                            <label for="exampleInputEmail1">სტატუსი</label>

                                                <select class="form-select mt-3" name='status'
                                                    aria-label="Default select example">
                                                    <?php if($project->status == 1): ?>
                                                    <option value="1">აქტიური</option>
                                                    <?php elseif($project->status == null): ?>
                                                    <option value="">დასრულებული</option>
                                                    <?php endif; ?>
                                                    <option value="">დასრულებული</option>
                                                    <option value="1">აქტიური</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-12 col-md-6 mt-5">
                                                <button class="btn btn-primary" type='submit'>დამატება</button>
                                            </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>




<div class="modal fade bd-example-modal-lg" id="add-porject" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">პროექტის დამატება</h5>
                <button type="button" class="close btn btn-primary" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action='<?php echo e(route("store.project")); ?>' method='post'>
                    <?php echo csrf_field(); ?>
                    <div class='row'>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">დასახელება</label>
                            <input type="text" name='name' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ფოტო</label>
                            <input type="file" name='image' class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">დაწყების თარიღი</label>
                            <input type="date" name='start_date' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">დასრულების თარიღი</label>
                            <input type="date" name='end_date' required class="form-control mt-2">
                        </div>

                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიები</label>
                            <select class="form-select mt-2" name='guarantee_id' aria-label="Default select example">
                                <option value="">არჩევა</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ჯამური ღირებულება</label>
                            <input type="number" name='price' step="0.01" required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ავანსის პროცენტი</label>
                            <input type="number" name='avance_percent' required min='0' max='100' required
                                class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">რეზერვის პროცენტი</label>
                            <input type="number" min='0' max='100' name='reserve_percent'
                             required class="form-control mt-2">
                        </div>

                        <div class="form-group col-12 col-md-6 mt-5">
                            <button class="btn btn-primary" type='submit'>დამატება</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/offroads/efg/resources/views/components/projects.blade.php ENDPATH**/ ?>