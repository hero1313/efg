
<?php $__env->startSection('content'); ?>
<button class='btn btn-primary add-project' data-toggle="modal" data-target="#add_guarantee">გარანტიის დამატება</button>

<div class="container-fluid flex-grow-1 container-p-y">
    <div class="card mt-5">
        <h5 class="card-header">გარანტიები</h5>
        <div class="table-responsive text-nowrap">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ნომერი</th>
                        <th>ბანკი</th>
                        <th>ღირებულება</th>
                        <th>შექმნის თარიღი</th>
                        <th>გარანტიის ვადა</th>
                        <th>ტიპი</th>
                        <th>სტატუსი</th>
                        <th>რედაქტირება</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $guarantees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guarantee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($guarantee->number); ?></td>
                        <td><?php echo e($guarantee->bank); ?></td>
                        <td><?php echo e($guarantee->price); ?></td>
                        <td><?php echo e($guarantee->release_date); ?></td>
                        <td><?php echo e($guarantee->deadline); ?></td>
                        <td>
                                <?php if($guarantee->type == 2): ?>
                                <button class='btn btn-success'>უძრავი ქონების უზრუნველყოფით</button>
                                <?php elseif($guarantee->type == 1): ?>
                                <button class='btn btn-danger'>უძრავი ქონების უზრუნველყოფის გარეშე</button>
                                <?php endif; ?>
                        </td>
                        <td>
                            <?php if($guarantee->status == 1): ?>
                            <button class='btn btn-success'>აქტიური</button>
                            <?php elseif($guarantee->status == null): ?>
                            <button class='btn btn-danger'>დასრულებული</button>
                            <?php endif; ?></td>
                        <td>
                            <button class='btn btn-primary' data-toggle="modal"
                                data-target="#edit_guarantee_<?php echo e($guarantee->id); ?>">რედაქტირება</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="add_guarantee" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">გეგმის დამატება</h5>
                <button type="button" class="close btn btn-primary" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action='<?php echo e(route("store.guarantee")); ?>' method='post'>
                    <?php echo csrf_field(); ?>
                    <div class='row'>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ნომერი</label>
                            <input type="text" name='number' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ბანკი</label>
                            <input type="text" name='bank' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ფასი</label>
                            <input type="number" name='price' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">შექმნის თარიღი</label>
                            <input type="date" name='release_date' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის ვადა</label>
                            <input type="date" name='deadline' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის ტიპი</label>
                            <select class="form-select mt-2" name="type" aria-label="Default select example">
                                <option value="1">უძრავი ქონების უზრუნველყოფით</option>
                                <option value="2">უძრავი ქონების უზრუნველყოფის გარეშე</option>
                            </select>
                        </div>
                        
                        <div class="form-group col-12 col-md-6 mt-5">
                            <button class="btn btn-primary" type='submit'>დამატება</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $guarantees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guarantee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade bd-example-modal-lg" id="edit_guarantee_<?php echo e($guarantee->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">გეგმის დამატება</h5>
                <button type="button" class="close btn btn-primary" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action='<?php echo e(route("update.guarantee",$guarantee->id)); ?>' method='post'>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class='row'>
                    <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ნომერი</label>
                            <input type="text" value="<?php echo e($guarantee->number); ?>" name='number' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ბანკი</label>
                            <input type="text" value="<?php echo e($guarantee->bank); ?>" name='bank' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ფასი</label>
                            <input type="text" value="<?php echo e($guarantee->price); ?>" name='price' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">შექმნის თარიღი</label>
                            <input type="text" value="<?php echo e($guarantee->release_date); ?>" name='release_date' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის ვადა</label>
                            <input type="text" value="<?php echo e($guarantee->deadline); ?>" name='deadline' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                             <label for="exampleInputEmail1">გარანტიის ტიპი</label>
                            <select class="form-select mt-2" name='type' aria-label="Default select example">
                                <?php if($guarantee->type == 2): ?>
                                <option value="2">უძრავი ქონების უზრუნველყოფით</option>
                                <?php elseif($guarantee->type == 1): ?>
                                <option value="1">უძრავი ქონების უზრუნველყოფის გარეშე</option>
                                <?php endif; ?>
                                <option value="1">უძრავი ქონების უზრუნველყოფის გარეშე</option>
                                <option value="2">უძრავი ქონების უზრუნველყოფით</option>
                            </select>
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის სტატუსი</label>
                            <select class="form-select mt-2" name='type' aria-label="Default select example">
                                <?php if($guarantee->status == 1): ?>
                                <option value="1">აქტიური</option>
                                <?php elseif($guarantee->status == null): ?>
                                <option value="">დასრულებული</option>
                                <?php endif; ?>
                                <option value="">დასრულებული</option>
                                <option value="1">აქტიური</option>
                            </select>
                        </div>
                        <div class="form-group col-12 col-md-6 mt-5">
                            <button class="btn btn-primary" type='submit'>რედაქტირება</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/offroads/efg/resources/views/components/guarantees.blade.php ENDPATH**/ ?>