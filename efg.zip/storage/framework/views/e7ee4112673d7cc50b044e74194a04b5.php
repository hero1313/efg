
<?php $__env->startSection('content'); ?>
<?php
$planePay = DB::table('project_plans')
->where('project_id', '=', $project->id)
->where('status', '=', null)
->sum('pay');
?>
<div class="row">
    <div class="col-md-5 col-12">
        <img class="project-img" src="https://imageio.forbes.com/b-i-forbesimg/houzz/files/2013/12/contemporary-exterior.jpg?format=jpg&width=500">
    </div>
    <div class="col-md-7 col-12 row mt-5">
        <div class="col-12 col-lg-6 col-xl-4">
            <div class="card plane-card">
                <h5 class="project-dashboard-card">სახელი</h5>
                <?php echo e($project->name); ?>

            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-4">
            <div class="card plane-card">
                <h5 class="project-dashboard-card">ჯამური ღირებულება</h5>
                <?php echo e($project->price); ?> ₾
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-4">
            <div class="card plane-card">
                <h5 class="project-dashboard-card">სტატუსი</h5>
                <?php if($project->status == 1): ?>
                <button class='btn btn-success'>მიმდინარე</button>
                <?php elseif($project->status == null): ?>
                <button class='btn btn-danger'>დასრულებული</button>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-3">
            <div class="card plane-card color-red">
                <h5 class="project-dashboard-card">საწყისი ავანსი</h5>
                <?php echo e($project->start_avance); ?> ₾
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-3">
            <div class="card plane-card color-green">
                <h5 class="project-dashboard-card">სერთიფიკატიდან გადახდილი თანხა</h5>
                <?php echo e($planePay); ?> ₾
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-3">
            <div class="card plane-card color-green">
                <h5 class="project-dashboard-card">ჯამურად გადახდილი თანხა</h5>
                <?php echo e($planePay + $project->start_avance); ?> ₾
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-3">
            <div class="card plane-card color-red">
                <h5 class="project-dashboard-card">დარჩენილი გადასახადი</h5>
                <?php echo e($project->price - ($planePay + $project->start_avance)); ?> ₾
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-6">
            <div class="card plane-card color-green">
                <h5 class="project-dashboard-card ">დაწყების თარიღი</h5>
                <?php echo e($project->start_date); ?>

            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-6">
            <div class="card plane-card color-red">
                <h5 class="project-dashboard-card ">დასრულების თარიღი</h5>
                <?php echo e($project->end_date); ?>

            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-3">
            <div class="card plane-card color-red">
                <h5 class="project-dashboard-card">დარჩენილი რეზერვი</h5>
                <?php echo e($project->reserve); ?> ₾
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-3">
            <div class="card plane-card color-red">
                <h5 class="project-dashboard-card">დაუკავებელი ავანსი</h5>
                <?php echo e($project->avance); ?> ₾
            </div>
        </div>

        <div class="col-12 col-lg-6 col-xl-3">
            <div class="card plane-card color-green">
                <h5 class="project-dashboard-card">შესრულებული სამუშაოები</h5>
                <?php echo e($done); ?> ₾

            </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-3">
            <div class="card plane-card color-red">
                <h5 class="project-dashboard-card ">დარჩენილი სამუშაოები</h5>
                <?php echo e($remaining); ?> ₾

            </div>
        </div>

    </div>
</div>

<div class="add-div">
    <button class='btn btn-primary add-project' data-toggle="modal" data-target="#add_plane">გეგმის სდამატება</button>
</div>
<div class="add-div" style="opacity: 0;">
    <button class='btn btn-primary add-project' data-toggle="modal" data-target="#add_plane">გეგმის სდამატება</button>
</div>

<div class="container-fluid flex-grow-1 container-p-y">
    <div class="card mt-5">
        <h5 class="card-header">პროექტის გეგმა </h5>
        <div class="table-responsive text-nowrap">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>დასახელება</th>
                        <th>ჯამური ღირებულება</th>
                        <th>დასრულების თარიღი</th>
                        <th>გადახდის თარიღი</th>
                        <th>ავანსის პროცენტი</th>
                        <th>ავანსი</th>
                        <th>რეზერვის პროცენტი</th>
                        <th>რეზერვი</th>
                        <th>გადასახდელი თანხა</th>
                        <th>სტატუსი</th>
                        <th>PDF</th>
                        <th>რედაქტირება</th>
                        <th>წაშლა</th>

                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $projectPlanes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectPlane): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <h6><?php echo e($projectPlane->name); ?></h6>
                        </td>
                        <!-- <td class="plane-desc">
                            <?php echo e($projectPlane->description); ?>

                        </td> -->
                        <td><?php echo e($projectPlane->price); ?> ₾</td>
                        <td><?php echo e($projectPlane->deadline_date); ?></td>
                        <td><?php echo e($projectPlane->pay_date); ?></td>
                        <td><?php echo e($projectPlane->avance_percent != null ? $projectPlane->avance_percent : "0"); ?> %</td>
                        <td><?php echo e($projectPlane->avance_price != null ? $projectPlane->avance_price : "0"); ?> ₾</td>
                        <td>
                            <?php echo e($projectPlane->reserve_percent != null ? $projectPlane->reserve_percent : "0"); ?> %
                        </td>
                        <td><?php echo e($projectPlane->reserve_price != null ? $projectPlane->reserve_price : "0"); ?> ₾</td>
                        <td><?php echo e($projectPlane->pay != null ? $projectPlane->pay : "0"); ?> ₾</td>
                        <td>
                            <?php if($projectPlane->status == 1): ?>
                            <button class='btn btn-success'>აქტიური</button>
                            <?php elseif($projectPlane->status == null): ?>
                            <button class='btn btn-danger'>დასრულებული</button>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('download.pdf',$projectPlane->id)); ?>">
                                <button class='btn btn-primary'>PDF</button>
                            </a>
                        </td>
                        <td>
                            <?php if($projectPlane->status == 1): ?>
                            <button class='btn btn-primary' data-toggle="modal" data-target="#edit_plane_<?php echo e($projectPlane->id); ?>">რედაქტირება</button>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($projectPlane->status == 1): ?>
                                <form action="<?php echo e(route('delete.project_plane', $projectPlane->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger">წაშლა</button>
                                </form>
                            <?php endif; ?>
                            
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="add_plane" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">გეგმის დამატება</h5>
                <button type="button" class="close btn btn-primary" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action='<?php echo e(route("store.project_plane",$project->id)); ?>' method='post'>
                    <?php echo csrf_field(); ?>
                    <div class='row'>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">დასახელება</label>
                            <input type="text" name='name' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ანაზღაურება</label>
                            <input type="number" step="0.01" name='price' required class="form-control mt-2 price">
                        </div>
                        <?php if($project->reserve < $project->start_reserve): ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">რეზერვის %</label>
                            <input type="number" id="reserve_percent" class="form-control mt-2 reserve_percent" name='reserve_percent' required min='0' max='100' value="0">
                        </div>
                        <?php else: ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">რეზერვის %</label>
                            <input type="number" id="reserve_percent" disabled name='reserve_percent' min='0' max='100' value="0" placeholder="რეზერვი ამოიწურა" class="form-control mt-2 reserve_percent">
                        </div>
                        <?php endif; ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">რეზერვის თანხა</label>
                            <input type="number" name='reserve_price' step="0.01" class="form-control reserve_price mt-2">
                        </div>

                        <div class="form-group col-12 col-md-4 mt-3">
                            <button type="button" onclick="calculateReserve()" class="btn btn-primary calc-btn">დათვლა</button>
                        </div>

                        <?php if($project->avance > 0): ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">ავანსის %</label>
                            <input type="number" id="avance_percent" name='avance_percent' required min='0' max='100' value="<?php echo e($project->avance_percent); ?>" class="form-control mt-2 avance_percent">
                        </div>
                        <?php else: ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">ავანსის %</label>
                            <input type="text" id="avance_percent" name='avance_percent' disabled placeholder="პროექტის ავანსი ამოიწურა" class="form-control mt-2 avance_percent">
                        </div>
                        <?php endif; ?>

                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">ავანსის თანხა</label>
                            <input type="number" name='avance_price' step="0.01" class="form-control avance_price mt-2">
                        </div>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <button type="button" onclick="calculatePrice()" class="btn btn-primary calc-btn">დათვლა</button>
                        </div>
                        <!-- <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">შესრულების ვადა</label>
                            <input type="date" name='deadline_date' required class="form-control mt-2">
                        </div> -->
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ანაზღაურების თარიღი</label>
                            <input type="date" name='pay_date' required class="form-control mt-2">
                        </div>
                        <!-- <div class="form-group col-12 col-md-12 mt-3">
                            <label for="exampleInputEmail1">აღწერა</label>
                            <textarea rows="6" type="text" class="form-control" id="description" name="description">

                            </textarea>
                        </div> -->

                        <div class="form-group col-12 col-md-6 mt-5">
                            <button class="btn btn-primary" type='submit'>დამატება</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $projectPlanes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectPlane): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
if($project->avance > 0 ){
$maxAvancePercent = 100 / ($projectPlane->price / $project->avance);
}
else{
$maxAvancePercent = 0;
}
if($maxAvancePercent > 100){
$maxAvancePercent = 100;
}
elseif($maxAvancePercent < 0){ $maxAvancePercent=0; } ?> <div class="modal fade bd-example-modal-lg" id="edit_plane_<?php echo e($projectPlane->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">გეგმის რედაქტირება </h5>
                <button type="button" class="close btn btn-primary" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action='<?php echo e(route("update.project_plane",$projectPlane->id)); ?>' method='post'>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class='row'>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">დასახელება</label>
                            <input type="text" value="<?php echo e($projectPlane->name); ?>" name='name' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ანაზღაურება</label>
                            <input type="text" value="<?php echo e($projectPlane->price); ?>" step="0.01" name='price' required class="form-control mt-2 price_<?php echo e($projectPlane->id); ?>">
                        </div>

                        <?php if($project->reserve < $project->start_reserve): ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">რეზერვის %</label>
                            <input type="number" id="reserve_price" step="0.01" name='reserve_percent' required min='0' max='100' value="<?php echo e($projectPlane->reserve_percent != null ? $projectPlane->reserve_percent : '0'); ?>" class="form-control mt-2 reserve_percent_<?php echo e($projectPlane->id); ?>">
                        </div>
                        <?php else: ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">რეზერვის %</label>
                            <input type="number" id="reserve_price" step="0.01" name='reserve_percent' disabled placeholder="რეზერვი ამოიწურა" min='0' max='100' value="<?php echo e($projectPlane->reserve_percent); ?>" class="form-control mt-2 reserve_percent_<?php echo e($projectPlane->id); ?>">
                        </div>
                        <?php endif; ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">რეზერვის თანხა</label>
                            <input type="number" value="<?php echo e($projectPlane->reserve_price); ?>" step="0.01" name='reserve_price' class="form-control reserve_price_<?php echo e($projectPlane->id); ?> mt-2">
                        </div>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <button type="button" onclick="calculateEditReserve(<?php echo e($projectPlane->id); ?>)" class="btn btn-primary calc-btn">დათვლა</button>
                        </div>
                        <?php if($project->avance > 0): ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">ავანსის პროცენტი</label>
                            <input type="number" id="avance_price" step="0.01" name='avance_percent' required min='0' max='<?php echo e($maxAvancePercent); ?>' value="<?php echo e($projectPlane->avance_percent); ?>" class="form-control mt-2 avance_percent_<?php echo e($projectPlane->id); ?>">
                        </div>
                        <?php else: ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">ავანსის %</label>
                            <input type="text" id="avance_percent" name='avance_percent' disabled placeholder="პროექტის ავანსი ამოიწურა" class="form-control mt-2 avance_percent_<?php echo e($projectPlane->id); ?>">
                        </div>
                        <?php endif; ?>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <label for="exampleInputEmail1">ავანსის თანხა</label>
                            <input type="number" value="<?php echo e($projectPlane->avance_price); ?>" step="0.01" name='avance_price' class="form-control avance_price_<?php echo e($projectPlane->id); ?> mt-2">
                        </div>
                        <div class="form-group col-12 col-md-4 mt-3">
                            <button type="button" onclick="calculateEditPrice(<?php echo e($projectPlane->id); ?>)" class="btn btn-primary calc-btn">დათვლა</button>
                        </div>

                        <!-- <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">შესრულების ვადა</label>
                            <input type="date" value="<?php echo e($projectPlane->deadline_date); ?>" required name='deadline_date'
                                class="form-control mt-2">
                        </div> -->

                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ანაზღაურების თარიღი</label>
                            <input type="date" value="<?php echo e($projectPlane->pay_date); ?>" required name='pay_date' class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">სტატუსი</label>
                            <select class="form-select" name='status' aria-label="Default select example">
                                <?php if($projectPlane->status == 1): ?>
                                <option value="1">აქტიური</option>
                                <?php elseif($projectPlane->status == null): ?>
                                <option value="">დასრულებული</option>
                                <?php endif; ?>
                                <option value="">დასრულებული</option>
                                <option value="1">აქტიური</option>
                            </select>
                        </div>
                        <!-- <div class="form-group col-12 col-md-12 mt-3">
                            <label for="exampleInputEmail1">აღწერა</label>
                            <textarea class="form-control w-100" name="description">
                                <?php echo e($projectPlane->description); ?>

                            </textarea>
                        </div> -->

                        <div class="form-group col-12 col-md-6 mt-5">
                            <button class="btn btn-primary" type='submit'>რედაქტირება</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <script>
        function calculatePrice() {
            if ($(".reserve_price").val() == null) {
                alert("ავანსის ფასის დასათვლელად გთხოვთ პირველ ეტაპზე დაითვალოთ რეზერვის თანხა")
            } else {
                if ($('.price').val()) {
                    $(".avance_price").empty();
                    var percent = parseFloat($('.avance_percent').val())
                    var price = parseFloat($('.price').val())
                    var value = (price - $(".reserve_price").val()) / 100 * percent
                    $(".avance_price").val(value.toFixed(2))
                } else {
                    alert("შეიყვანეთ ანაზღაურება")
                }
            }


        }

        function calculateEditPrice($id) {


            if ($(".reserve_price_" + $id).val() == null) {
                alert("ავანსის ფასის დასათვლელად გთხოვთ პირველ ეტაპზე დაითვალოთ რეზერვის თანხა")
            } else {
                $(".avance_price_" + $id).empty();
                var percent = parseFloat($('.avance_percent_' + $id).val())
                var price = parseFloat($('.price_' + $id).val())
                var value = (price - $(".reserve_price_" + $id).val()) / 100 * percent
                $(".avance_price_" + $id).val(value.toFixed(2))
            }
        }

        function calculateReserve() {
            if ($('.price').val()) {
                $(".reserve_price").empty();
                var percent = parseFloat($('.reserve_percent').val())
                var price = parseFloat($('.price').val())
                var value = price / 100 * percent
                $(".reserve_price").val(value.toFixed(2))
            } else {
                alert("შეიყვანეთ ანაზღაურება")
            }
        }

        function calculateEditReserve($id) {
            $(".reserve_price_" + $id).empty();
            var percent = parseFloat($('.reserve_percent_' + $id).val())
            var price = parseFloat($('.price_' + $id).val())
            var value = price / 100 * percent
            $(".reserve_price_" + $id).val(value.toFixed(2))
        }
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/offroads/efg/resources/views/components/project.blade.php ENDPATH**/ ?>