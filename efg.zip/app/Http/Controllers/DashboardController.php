<?php

namespace App\Http\Controllers;

use App\Models\guarantee;
use App\Models\Project;
use Illuminate\Http\Request;
use App\Models\ProjectPlan;


class DashboardController extends Controller
{
    public function index()
    {
        $projectsQuantity = Project::all()->count();
        $activeProjectsQuantity = Project::where('status',1)->count();
        $endedProjectsQuantity = Project::where('status','!=',1)->count();
        $endedProjectsPrice = Project::where('status','!=',1)->sum('price');

        $plannedStartAvance =  ProjectPlan::where('status', null)->sum('avance_price');
        $projectsCost = Project::all()->sum('price');
        // გადახდილი თანხა
        $plannedFunds =  ProjectPlan::where('status', null)->sum('pay');

        $cash = Guarantee::all()->sum('price');
        $udzravi = Guarantee::all()->sum('reserve_price');
        $grantscash = Guarantee::all()->sum('price');
        $grantsudzravi = Guarantee::all()->sum('price');

        $grantsFree = $grantscash + $grantsudzravi - $cash - $udzravi;

        $cash1 = Guarantee::all()->sum('start_price');
        $udzravi2 = Guarantee::all()->sum('start_reserve_price'); 
        $grantLimit = $cash1 + $udzravi2;


        $taxAmounts = $projectsCost - $plannedFunds - $plannedStartAvance;

        $lastPlanes = ProjectPlan::where('status', '=', null)->latest()->take(10)->get();
        
        $avanceRemains = Project::all()->sum('avance');

        return view('components.dashboard', compact(['projectsQuantity','cash','udzravi','grantsFree','grantLimit','activeProjectsQuantity','endedProjectsQuantity','endedProjectsPrice', 'taxAmounts','projectsCost','lastPlanes','avanceRemains','plannedFunds',]));

    }
}