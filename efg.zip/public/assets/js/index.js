$(document).ready(function () {
   
});

$(".gray-background").click(function () {
    $(".hidden-cover").css("display", "none");
});
$(".close-nav").click(function () {
    $(".hidden-cover").css("display", "none");
});
$(".burger").click(function () {
    $(".hidden-cover").css("display", "flex");
});