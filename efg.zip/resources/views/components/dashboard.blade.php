@extends('index')
@section('content')
<div class="container-fluid flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-md-8 col-lg-8 order-2 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="card-title m-0 me-2">ბოლოს შესრულებული გადახდები</h5>
                </div>
                <div class="card-body last-week-transaction">
                    <ul class="p-0 m-0">
                        @foreach($lastPlanes as $lastPlane)
                        <li class="d-flex mb-4 pb-1">
                            <div class="avatar flex-shrink-0 me-3">
                                <i class="menu-icon tf-icons bx bx-box pay-icon"></i>
                            </div>
                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                <div class="me-2">
                                    <h6 class="mb-0">{{$lastPlane->name}}</h6>
                                </div>
                                <div class="user-progress  align-items-center gap-1">
                                    <span class="text-muted">ღირებულება</span>
                                    <h6 class="mb-0 comma">{{$lastPlane->price}} ₾</h6>
                                </div>
                            </div>
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-4 order-1">
            <div class="row">
                <div class="col-lg-12 col-xl-4 col-md-12 col-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">პროექტების რაოდენობა</span>
                            <h3 class="card-title color-main mb-2">{{$projectsQuantity}}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">აქტიური პროექტები</span>
                            <h3 class="card-title color-green mb-2">{{$activeProjectsQuantity}}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">დასრულებული პროექტები</span>
                            <h3 class="card-title  color-red mb-2">{{$endedProjectsQuantity}}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">გადახდილი თანხების ჯამი</span>
                            <h3 class="card-title color-green mb-2 comma">{{$plannedFunds}}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">დასრულებული პროექტების თანხების ჯამი</span>
                            <h3 class="card-title color-green mb-2 comma">{{$endedProjectsPrice}}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">გადასახდელი თანხების ჯამი</span>
                            <h3 class="card-title color-green mb-2 comma">{{$taxAmounts}} </h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">ავანსის ნაშთი</span>
                            <h3 class="card-title color-red mb-2 comma">{{$avanceRemains}} </h3>
                        </div>
                    </div>
                </div>
                <!-- გამონთავისუფლებული -->

                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">ქეშით უზრუნველყოფილი გრანტები</span>
                            <h3 class="card-title color-green mb-2 comma">{{$cash}} </h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">უძრავი ქონებით უზრუნველყოფილი გრანტები</span>
                            <h3 class="card-title color-red mb-2 comma">{{$udzravi}} </h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">გამონთავისუფლებული</span>
                            <h3 class="card-title color-green mb-2 comma">{{$grantsFree}} </h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">გრანტების ლიმიტი</span>
                            <h3 class="card-title color-red mb-2 comma">{{$grantLimit}} </h3>
                        </div>
                    </div>
                </div>

                <!--  -->
                <div class="col-lg-12 col-md-12 col-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <span class="fw-semibold d-block mb-1">პროექტების ღირებულების ჯამი</span>
                            <h3 class="card-title color-main mb-2 comma">{{$projectsCost}} </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
@stop