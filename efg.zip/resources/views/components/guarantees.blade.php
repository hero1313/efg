@extends('index')
@section('content')
<button class='btn btn-primary add-project' data-toggle="modal" data-target="#add_guarantee">გარანტიის დამატება</button>

<div class="container-fluid flex-grow-1 container-p-y">
    <form action="/guarantees" method="get">
        <div class="form-group d-flex mt-3 mb-3 search-div">
            <input type="text" name='search' class="form-control mt-2 search" value="{{$search}}" placeholder="მოძებნე პროექტი">
            <button class="btn btn-primary">ძებნა</button>
        </div>
    </form>
    <div class="card mt-5">
        <h5 class="card-header">გარანტიები</h5>
        <div>
        <div class="table-responsive text-nowrap">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>რედაქტირება</th>
                        <th>სტატუსი</th>
                        <th>ტიპი</th>
                        <th>პროექტი</th>
                        <th>ნომერი</th>
                        <th>ბანკი</th>
                        <th>გარანტიის ჯამური ღირებულება</th>
                        <th>გამონთავისუფლებული</th>
                        <th>ქეშით უზრუნველყოფილი საწყისი ღირებულება</th>
                        <th>ქეშით უზრუნველყოფილი დარჩენილი თანხა</th>
                        <th>ქონებით უზრუნველყოფილი საწყისი ღირებულება</th>
                        <th>ქონებით უზრუნველყოფილი დარჩენილი თანხა</th>
                        <th>შექმნის თარიღი</th>
                        <th>გარანტიის ვადა</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @foreach($guarantees as $guarantee)
                    @php
                    $project = DB::table('projects')
                    ->where('id', '=', $guarantee->project_id)->first();
                    @endphp
                    <tr>
                        <td>
                            <button class='btn btn-primary' data-toggle="modal" data-target="#edit_guarantee_{{$guarantee->id}}">რედაქტირება</button>
                        </td>
                        <td>
                            @if($guarantee->deadline < $limitDate) <button class='btn btn-warning'>ვადა გასდის</button>
                                @elseif($guarantee->deadline < $today) <button class='btn btn-danger'>დასრულებული</button>
                                    @elseif($guarantee->deadline > $today)
                                    <button class='btn btn-success'>აქტიური</button>
                                    @endif
                        </td>
                        <td>
                            @if($guarantee->type == 2)
                            <button class='btn btn-success'>რეზერვის გარანტია</button>
                            @elseif($guarantee->type == 1)
                            <button class='btn btn-primary'>ავანსის გარანტია</button>
                            @endif
                        </td>
                        <td>{{$project->name}}</td>
                        <td>{{$guarantee->number}}</td>
                        <td>{{$guarantee->bank}}</td>
                        <td class="comma">{{$guarantee->start_price + $guarantee->start_reserve_price}}</td>
                        <td class="comm">
                            @if($guarantee->type == 2 && $guarantee->deadline < $today) {{$guarantee->start_price + $guarantee->start_reserve_price}} @elseif($guarantee->type == 1)
                                {{$guarantee->start_price + $guarantee->start_reserve_price - $guarantee->price - $guarantee->reserve_price}}
                                @endif
                        </td>
                        <td class="comma">{{$guarantee->start_price}}</td>
                        <td class="comma">{{$guarantee->price}}</td>
                        <td class="comma">{{$guarantee->start_reserve_price}}</td>
                        <td class="comma">{{$guarantee->reserve_price}}</td>
                        <td>{{$guarantee->release_date}}</td>
                        <td>{{$guarantee->deadline}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="add_guarantee" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">გეგმის დამატება</h5>
                <button type="button" class="close btn btn-primary" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action='{{route("store.guarantee")}}' method='post'>
                    @csrf
                    <div class='row'>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">პროექტი</label>
                            <select class="form-select mt-2" name="project_id" aria-label="Default select example">
                                @foreach($projects as $project)
                                <option value="{{$project->id}}">{{$project->name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ნომერი</label>
                            <input type="text" name='number' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ბანკი</label>
                            <input type="text" name='bank' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ქეშით უზრუნველყოფილი</label>
                            <input type="number" name='price' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ქონებით უზრუნველყოფილი</label>
                            <input type="number" name='reserve_price' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">შექმნის თარიღი</label>
                            <input type="date" name='release_date' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის ვადა</label>
                            <input type="date" name='deadline' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის ტიპი</label>
                            <select class="form-select mt-2" name="type" aria-label="Default select example">
                                <option value="2">რეზერვის გარანტია</option>
                                <option value="1">ავანსის გარანტია</option>
                            </select>
                        </div>
                        <div class="form-group col-12 col-md-6 mt-5">
                            <button class="btn btn-primary" type='submit'>დამატება</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@foreach($guarantees as $guarantee)

<div class="modal fade bd-example-modal-lg" id="edit_guarantee_{{$guarantee->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">გეგმის დამატება</h5>
                <button type="button" class="close btn btn-primary" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action='{{route("update.guarantee",$guarantee->id)}}' method='post'>
                    @csrf
                    @method('PUT')
                    <div class='row'>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ნომერი</label>
                            <input type="text" value="{{$guarantee->number}}" name='number' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ბანკი</label>
                            <input type="text" value="{{$guarantee->bank}}" name='bank' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ქეშით უზრუნველყოფილი</label>
                            <input type="text" value="{{$guarantee->price}}" name='price' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">ქონებით უზრუნველყოფილი</label>
                            <input type="number" name='reserve_price' value="{{$guarantee->reserve_price}}" required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">შექმნის თარიღი</label>
                            <input type="text" value="{{$guarantee->release_date}}" name='release_date' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის ვადა</label>
                            <input type="text" value="{{$guarantee->deadline}}" name='deadline' required class="form-control mt-2">
                        </div>
                        <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის ტიპი</label>
                            <select class="form-select mt-2" name='type' aria-label="Default select example">
                                @if($guarantee->type == 2)
                                <option value="2">რეზერვის გარანტია</option>
                                @elseif($guarantee->type == 1)
                                <option value="1">ავანსის გარანტია</option>
                                @endif
                                <option value="1">ავანსის გარანტია</option>
                                <option value="2">რეზერვის გარანტია</option>
                            </select>
                        </div>
                        <!-- <div class="form-group col-12 col-md-6 mt-3">
                            <label for="exampleInputEmail1">გარანტიის სტატუსი</label>
                            <select class="form-select mt-2" name='type' aria-label="Default select example">
                                @if($guarantee->status == 1)
                                <option value="1">აქტიური</option>
                                @elseif($guarantee->status == null)
                                <option value="">დასრულებული</option>
                                @endif
                                <option value="">დასრულებული</option>
                                <option value="1">აქტიური</option>
                            </select>
                        </div> -->
                        <div class="form-group col-12 col-md-6 mt-5">
                            <button class="btn btn-primary" type='submit'>რედაქტირება</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endforeach
@stop